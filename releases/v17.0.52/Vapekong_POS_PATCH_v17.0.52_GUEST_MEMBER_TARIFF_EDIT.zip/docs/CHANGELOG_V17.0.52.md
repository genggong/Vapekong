# CHANGELOG V17.0.52

Rilis patch Vapekong POS/Marketplace.

## Pembaruan

### 1. Edit Tarif Kurir Toko (courier-rates)
- Menambah tombol **Edit** pada setiap baris tarif.
- Sebelumnya hanya ada tombol Hapus, sehingga untuk mengubah tarif harus mengisi
  ulang Provinsi → Kota → Kecamatan → Kelurahan dari nol ("minta isi kolom provinsi
  terus menerus").
- Kini tombol Edit mengisi otomatis cascade wilayah + nilai fee/eta/sort_order/is_active
  dari data tersimpan, lalu menyorot formulir. Simpan tetap memakai ON DUPLICATE KEY UPDATE
  sehingga tarif yang sama ter-update, bukan create baru.

### 2. Guest checkout → tautkan/ buat member
Di `Marketplace.php` (`marketplace_create_order`), untuk checkout tamu (belum login):
- **Nomor HP sudah terdaftar sebagai member** → transaksi otomatis ditautkan ke member
  tersebut (customer_id = id member aktif dengan nomor itu).
- **Nomor HP belum terdaftar** → dibuatkan member otomatis:
  - name = nama penerima
  - phone = nomor HP penerima
  - email diisi bila ada
  - password default `vapekong123` (hash bcrypt)
  - status = active

## Berkas diubah

- `legacy/app/Modules/Marketplace/Marketplace.php`
- `legacy/public/admin/marketplace-courier-rates/index.php`
- `VERSION` → 17.0.52

## Cara pasang

1. Backup database & folder website.
2. Upload/extract zip (Overwrite/Replace) ke docroot yang berisi `index.php`, `app`, `legacy`.
3. Buka `/admin/system-upgrade/index.php` → **Jalankan Upgrade Otomatis**.
4. Purge cache (LiteSpeed Cache / browser).
5. Tes: Edit tarif kurir toko; checkout sebagai tamu dengan nomor member & nomor baru.
