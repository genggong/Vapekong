<?php
require_once __DIR__.'/../../../app/bootstrap.php';
require_once __DIR__.'/../../../app/Modules/Marketplace/Marketplace.php';
Auth::requireRole(['super_admin','owner']);
$pageTitle='Tarif Kurir Toko per Kelurahan';
$db=Database::connect();marketplace_install($db);marketplace_v16_install($db);
$error='';
if(is_post()){
    if(!CSRF::verify()){$error='Token keamanan tidak valid.';}else try{
        $action=(string)($_POST['action']??'save');
        if($action==='delete'){
            $id=max(0,(int)($_POST['id']??0));
            $db->prepare('DELETE FROM marketplace_store_courier_rates WHERE id=?')->execute([$id]);
            flash('success','Tarif kelurahan dihapus.');
        }else{
            $province=trim((string)($_POST['province_name']??''));$city=trim((string)($_POST['city_name']??''));$district=trim((string)($_POST['district_name']??''));$subdistrict=trim((string)($_POST['subdistrict_name']??''));
            if($province===''||$city===''||$district===''||$subdistrict==='')throw new InvalidArgumentException('Pilih wilayah sampai Kelurahan/Desa.');
            $resolved=marketplace_rajaongkir_resolve_direct_destination($subdistrict,$district,$city,trim((string)($_POST['postal_code']??'')));
            $destinationId=(int)($resolved['id']??0);if($destinationId<=0)throw new RuntimeException('Kelurahan belum dapat dipetakan ke ID tujuan ongkir.');
            $fee=max(0,(float)($_POST['fee']??0));$eta=trim((string)($_POST['eta']??''));$active=isset($_POST['is_active'])?1:0;$sort=(int)($_POST['sort_order']??0);
            $sql="INSERT INTO marketplace_store_courier_rates(destination_id,province_id,city_id,district_id,subdistrict_id,province,city,district,subdistrict,postal_code,fee,eta,is_active,sort_order,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE province_id=VALUES(province_id),city_id=VALUES(city_id),district_id=VALUES(district_id),subdistrict_id=VALUES(subdistrict_id),province=VALUES(province),city=VALUES(city),district=VALUES(district),subdistrict=VALUES(subdistrict),postal_code=VALUES(postal_code),fee=VALUES(fee),eta=VALUES(eta),is_active=VALUES(is_active),sort_order=VALUES(sort_order),updated_at=NOW()";
            $db->prepare($sql)->execute([$destinationId,(int)($_POST['province_id']??0),(int)($_POST['city_id']??0),(int)($_POST['district_id']??0),(int)($_POST['subdistrict_id']??0),$province,$city,$district,$subdistrict,(string)($resolved['zip_code']??''),$fee,$eta?:null,$active,$sort]);
            flash('success','Tarif '.$subdistrict.' berhasil disimpan.');
        }
        legacy_redirect('admin/marketplace-courier-rates/index.php');
    }catch(Throwable $e){$error=$e->getMessage();}
}
$rows=marketplace_v16_store_courier_rate_rows($db);$ok=flash('success');
require __DIR__.'/../../layouts/admin-header.php';require __DIR__.'/../../layouts/admin-sidebar.php';
?>
<main class="admin-main"><header class="admin-topbar"><button class="sidebar-toggle" id="sidebarToggle"><i class="bi bi-list"></i></button><div class="topbar-title"><h1>Tarif Kurir Toko per Kelurahan</h1><p>Pisahkan ongkir lokal berdasarkan Kelurahan/Desa tujuan.</p></div><div class="topbar-actions"><a class="btn-soft" href="<?=legacy_base_url('admin/marketplace-settings/index.php')?>"><i class="bi bi-arrow-left"></i> Pengaturan Marketplace</a></div></header>
<?php if($ok):?><div class="alert alert-success mt-3"><?=e($ok)?></div><?php endif;?><?php if($error):?><div class="alert alert-danger mt-3"><?=e($error)?></div><?php endif;?>
<section class="premium-card mt-4"><div class="card-head"><div><h3>Tambah / Perbarui Tarif</h3><p>Pilih berurutan Provinsi → Kota/Kabupaten → Kecamatan → Kelurahan/Desa.</p></div></div><form method="post" id="rateForm" class="premium-form"><?=CSRF::input()?><input type="hidden" name="action" value="save"><input type="hidden" name="province_name" id="provinceName"><input type="hidden" name="city_name" id="cityName"><input type="hidden" name="district_name" id="districtName"><input type="hidden" name="subdistrict_name" id="subdistrictName"><input type="hidden" name="postal_code" id="postalCode"><div class="form-grid"><div class="form-group"><label>Provinsi</label><select name="province_id" id="rateProvince" required><option value="">Pilih Provinsi</option></select></div><div class="form-group"><label>Kota / Kabupaten</label><select name="city_id" id="rateCity" disabled required><option value="">Pilih Kota/Kabupaten</option></select></div><div class="form-group"><label>Kecamatan</label><select name="district_id" id="rateDistrict" disabled required><option value="">Pilih Kecamatan</option></select></div><div class="form-group"><label>Kelurahan / Desa</label><select name="subdistrict_id" id="rateSubdistrict" disabled required><option value="">Pilih Kelurahan/Desa</option></select></div><div class="form-group"><label>Ongkir</label><input type="number" name="fee" min="0" step="1000" value="10000" required></div><div class="form-group"><label>Estimasi</label><input name="eta" placeholder="Contoh: 1-2 jam"></div><div class="form-group"><label>Urutan</label><input type="number" name="sort_order" value="0"></div><div class="form-group"><label>Status</label><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="is_active" checked> Aktif</label></div></div><div class="form-actions"><button class="btn-premium"><i class="bi bi-save"></i> Simpan Tarif</button></div></form></section>
<section class="premium-card mt-4"><div class="card-head"><div><h3>Daftar Tarif Kelurahan</h3><p><?=count($rows)?> wilayah tersimpan.</p></div></div><div class="table-responsive"><table class="premium-table"><thead><tr><th>Kelurahan/Desa</th><th>Kecamatan</th><th>Kota</th><th>Ongkir</th><th>ETA</th><th>Status</th><th>Aksi</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><b><?=e($r['subdistrict'])?></b><br><small><?=e($r['province'])?></small></td><td><?=e($r['district'])?></td><td><?=e($r['city'])?></td><td><?=rupiah($r['fee'])?></td><td><?=e($r['eta']?:setting('marketplace_store_courier_eta','1-3 jam'))?></td><td><?=$r['is_active']?'Aktif':'Off'?></td><td style="white-space:nowrap"><button type="button" class="btn-soft" onclick="rateEdit(<?= htmlspecialchars(json_encode(['id'=>(int)$r['id'],'province_id'=>(int)$r['province_id'],'city_id'=>(int)$r['city_id'],'district_id'=>(int)$r['district_id'],'subdistrict_id'=>(int)$r['subdistrict_id'],'province'=>$r['province'],'city'=>$r['city'],'district'=>$r['district'],'subdistrict'=>$r['subdistrict'],'postal_code'=>$r['postal_code'],'fee'=>(float)$r['fee'],'eta'=>$r['eta'],'sort_order'=>(int)$r['sort_order'],'is_active'=>(int)$r['is_active']]), ENT_QUOTES, 'UTF-8')?>"><i class="bi bi-pencil"></i> Edit</button> <form method="post" style="display:inline-block" onsubmit="return confirm('Hapus tarif <?=e(addslashes($r['subdistrict']))?>?')"><?=CSRF::input()?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn-soft" type="submit"><i class="bi bi-trash"></i> Hapus</button></form></td></tr><?php endforeach;?><?php if(!$rows):?><tr><td colspan="7">Belum ada tarif per kelurahan.</td></tr><?php endif;?></tbody></table></div></section></main>
<script>
(()=>{const endpoint='<?=e(legacy_base_url('store/api/region-options.php'))?>';const p=document.getElementById('rateProvince'),c=document.getElementById('rateCity'),d=document.getElementById('rateDistrict'),s=document.getElementById('rateSubdistrict');
const fill=async(el,level,parent=0)=>{el.disabled=true;el.innerHTML='<option value="">Memuat...</option>';try{const r=await fetch(endpoint+'?level='+encodeURIComponent(level)+(parent?'&parent_id='+parent:''),{credentials:'same-origin'});const j=await r.json();if(!j.success)throw new Error(j.message||'Gagal memuat wilayah');el.innerHTML='<option value="">Pilih '+(level==='province'?'Provinsi':level==='city'?'Kota/Kabupaten':level==='district'?'Kecamatan':'Kelurahan/Desa')+'</option>'+j.data.map(x=>'<option value="'+x.id+'" data-zip="'+(x.zip_code||'')+'">'+x.name+'</option>').join('');el.disabled=false;}catch(e){el.innerHTML='<option value="">'+e.message+'</option>';}};
const name=(el)=>el.options[el.selectedIndex]?.text||'';p.addEventListener('change',()=>{document.getElementById('provinceName').value=name(p);c.innerHTML='<option value="">Pilih Kota/Kabupaten</option>';d.innerHTML='<option value="">Pilih Kecamatan</option>';s.innerHTML='<option value="">Pilih Kelurahan/Desa</option>';if(p.value)fill(c,'city',p.value)});c.addEventListener('change',()=>{document.getElementById('cityName').value=name(c);if(c.value)fill(d,'district',c.value)});d.addEventListener('change',()=>{document.getElementById('districtName').value=name(d);if(d.value)fill(s,'subdistrict',d.value)});s.addEventListener('change',()=>{document.getElementById('subdistrictName').value=name(s);document.getElementById('postalCode').value=s.options[s.selectedIndex]?.dataset.zip||''});window.rateEdit=async(d)=>{
  document.querySelector('[name=fee]').value=d.fee;
  document.querySelector('[name=eta]').value=d.eta||'';
  document.querySelector('[name=sort_order]').value=d.sort_order;
  document.querySelector('[name=is_active]').checked=!!d.is_active;
  document.getElementById('rateForm').scrollIntoView({behavior:'smooth',block:'start'});
  await fill(p,'province'); p.value=String(d.province_id); p.disabled=false;
  await fill(c,'city',d.province_id); c.value=String(d.city_id); c.disabled=false;
  await fill(d,'district',d.city_id); d.value=String(d.district_id); d.disabled=false;
  await fill(s,'subdistrict',d.district_id); s.value=String(d.subdistrict_id); s.disabled=false;
  document.getElementById('provinceName').value=d.province;
  document.getElementById('cityName').value=d.city;
  document.getElementById('districtName').value=d.district;
  document.getElementById('subdistrictName').value=d.subdistrict;
  document.getElementById('postalCode').value=d.postal_code;
};
fill(p,'province');})();
</script>
<?php require __DIR__.'/../../layouts/admin-footer.php';?>
