<?php

return [
    'host' => 'localhost',
    'database' => 'vapekong_pos',
    'username' => 'vapekong_pospalasanga',
    'password' => 'M@ver1ck',
    'charset' => 'utf8mb4',
];
